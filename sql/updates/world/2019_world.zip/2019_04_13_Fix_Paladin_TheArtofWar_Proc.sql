DELETE FROM `spell_proc_event` WHERE `entry`=-53486;
INSERT INTO `spell_proc_event` (`entry`, `SchoolMask`, `SpellFamilyName`, `SpellFamilyMask0`, `SpellFamilyMask1`, `SpellFamilyMask2`, `procFlags`, `procEx`, `ppmRate`, `CustomChance`, `Cooldown`) VALUES (-53486, 1, 10, 0, 0, 0, 4, 0, 0, 0, 0);

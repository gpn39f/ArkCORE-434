DELETE FROM `spell_script_names` WHERE `spell_id`=6353 AND `ScriptName`='spell_warl_soulfire';
INSERT INTO `spell_script_names` (`spell_id`, `ScriptName`) VALUES (6353, 'spell_warl_soulfire');

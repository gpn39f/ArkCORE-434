
ALTER TABLE `gossip_menu_option`
MODIFY COLUMN `menu_id`  mediumint(8) UNSIGNED NOT NULL DEFAULT 0 FIRST ;

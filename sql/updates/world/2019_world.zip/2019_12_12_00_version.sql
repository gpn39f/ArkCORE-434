
UPDATE version SET db_version = "ArkDB 7.10.0 - 2019-DEC-12 for ArkCORE-434"; 
